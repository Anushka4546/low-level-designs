package TicTacToe;

public enum EventType {
    WIN("WIN"), 
    DRAW("DRAW"),
    INPROGRESS("INPROGRESS");


    private String event;
    
    EventType(String event) {
        this.event = event;
    }

    public String getValue() {
        return this.event;
    }
}
