package TicTacToe;

public class PlayerFactory {
    public Player createPlayer(String type, String name, Symbol symbol) {
        if(type.equals("Human")) {
            return new HumanPlayer(name, symbol);
        } else if(type.equals("Computer")) {
            return new ComputerPlayer(name, symbol);
        } else {
            return null; // should not be the case;
        }
    }
}
