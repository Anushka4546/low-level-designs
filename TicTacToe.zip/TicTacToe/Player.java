package TicTacToe;

import java.util.Scanner;

abstract public class Player {
    String name;
    Symbol symbol;

    Player(String name, Symbol symbol) {
        this.name = name;
        this.symbol = symbol;
    }

    abstract public Move getMove(Board board, Scanner scn);

    String getName() {
        return this.name;
    }

    Symbol getSymbol() {
        return this.symbol;
    }
}
