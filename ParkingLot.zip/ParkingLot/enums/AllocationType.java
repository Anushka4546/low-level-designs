package ParkingLot.enums;

public enum AllocationType {
    NearElevatorStrategy,
    NearEntranceStrategy;
}
