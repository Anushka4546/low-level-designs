package ParkingLot.enums;

public enum SpotStatus {
    BOOKED,
    FREE;
}