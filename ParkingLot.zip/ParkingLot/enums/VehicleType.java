package ParkingLot.enums;

public enum VehicleType {
    TWOWHEELER,
    FOURWHEELER
}
