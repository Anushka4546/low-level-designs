package ParkingLot.PaymentStrategy;

public interface PaymentStrategy {
    boolean pay(double amount);
}
